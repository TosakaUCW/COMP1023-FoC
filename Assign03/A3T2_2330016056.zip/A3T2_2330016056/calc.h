// int calculate
int calculate(int a, char c, int b);